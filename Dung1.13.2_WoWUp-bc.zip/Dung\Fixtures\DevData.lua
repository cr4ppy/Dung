--local function dump(var, ...) return DevTools_Dump(var, ...) end

local _, Dung = ...

function Dung:RunFixtures(stop)
    --local name = 'Hippo';
    --local guid_name = UnitName("player")..'-'..GetRealmName();

    --, ,'H ramps tank dps','ramps heals', 'zg tank', 'sp', 'dm heals', 'zg', 'ub', 'sethekk'
    --for i,dummy_msg in ipairs({'sp H tank dps heals','sp H dps', 'dm', 'zf','ub','H ramps tank dps','ramps heals', 'zg tank', 'sp', 'dm heals', 'zg', 'ub', 'sethekk'}) do
    --    if i == 5 then
    --        dummy_msg = 'sp tank heals dps This music is entertaining. It put me in positive thinking. One day this pandemic going away soon where we can enjoy the outdoor without the mask and better understand our physical condition.'
    --    end
    --    if i == 5 then
    --        name = 'Wfleldo'
    --    end
    --    Dung:OnChat(dummy_msg, name..i..'-'..GetRealmName(), nil)
    --end

    --Dung:OnChat('DPS LFG kara', 'Bluefork',nil, 'SHAMAN')
    --Dung:OnChat('LF1M, heals SP (N)', 'Cheesey',nil, 'WARLOCK')
    --Dung:OnChat('LF1M, heals SP h', 'Wowdf',nil, 'PALADIN')
    --Dung:OnChat('LF1m heals sethekk H', 'Oakee', nil, 'WARRIOR')
    --Dung:OnChat('LF2 tank/heals SV', 'Wifey', nil, 'MAGE')
    --Dung:OnChat('LF2m DPS HEALS SH H', 'Blindinglight', nil, 'PALADIN')
    --Dung:OnChat('LFM heals bm N', 'Oldgrog', nil, 'MAGE')
    --Dung:OnChat('lfg h sl', 'Dadalyf', nil, 'PRIEST')
    --
    --Dung:OnChat('LF1m heals scholo', 'Oakee', nil, 'WARRIOR')
    --Dung:OnChat('LF1m heals naxx', 'Cheefse', nil, 'SHAMAN')
    --
    --Dung:OnChat('LFM H ramps', 'Cowdoy', nil, 'SHAMAN')
    --Dung:OnChat('LFM karas tank 2 dps', 'Hiit', nil, 'WARRIOR')
    --Dung:OnChat('LF3M crypts dps', 'Hiit', nil, 'WARRIOR')
    --Dung:OnChat('LFM karas tank 2 dps', 'Manuc', nil, 'HUNTER')
    --Dung:OnChat('dps lfg crypts H', 'Trilly', nil, 'HUNTER')
    --Dung:OnChat('LFM RAMPS NEED ALL', 'Nathan', nil, 'PRIEST')
    --dump(string.gsub("{star}DPS{star}",'{star}', ""));
    --Dung:Show();
    --Dung.isRunning = false;
end