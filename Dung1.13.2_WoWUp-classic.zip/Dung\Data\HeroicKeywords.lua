local _, Dung = ...

Dung.Data.HeroicKeywords = {
    'H',
    'Heroic',
    '(H)',
    '-H',
    'H-',
    '-H-'
}